<template>
  <div><tag></tag></div>
</template>

<script setup>
import tag from '../../components/tag.vue'
</script>
<style lang="scss" scoped></style>
